"""Settings come from environment variables / a local .env file. Secrets are never logged."""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
BROKERS = ("pocketoption", "quotex", "iqoption", "binomo")


def load_env(path: Path | None = None) -> None:
    path = path or ROOT / ".env"
    if not path.exists():
        return
    for line in path.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


def _list(name: str, default: str = "") -> list[str]:
    return [x.strip() for x in os.getenv(name, default).split(",") if x.strip()]


def _flag(name: str, default: bool = False) -> bool:
    return os.getenv(name, "1" if default else "0").strip().lower() in ("1", "true", "yes", "on")


@dataclass
class Settings:
    host: str = "127.0.0.1"
    port: int = 8000
    data_dir: Path = ROOT / "data"
    models_dir: Path = ROOT / "models"
    payout: float = 0.85
    allow_unvalidated: bool = False
    min_confluence: int = 0
    seed_candles: int = 3000
    max_signal_age_s: float = 20.0  # drop a signal if its candle closed more than this many seconds ago (0 = off)
    # forex
    forex_provider: str = ""
    forex_symbols: list[str] = field(default_factory=list)
    oanda_token: str = ""
    oanda_account: str = ""
    oanda_env: str = "practice"
    twelvedata_key: str = ""
    twelvedata_poll_s: float = 15.0
    # brokers (read-only data collection)
    broker_ssid: dict[str, str] = field(default_factory=dict)
    broker_symbols: dict[str, list[str]] = field(default_factory=dict)
    enable_demo: bool = False

    @property
    def db_path(self) -> Path:
        return self.data_dir / "candles.sqlite3"

    def secrets(self) -> list[str]:
        vals = [self.oanda_token, self.twelvedata_key, *self.broker_ssid.values()]
        return [v for v in vals if v and len(v) >= 6]

    def redact(self, text: str) -> str:
        for s in self.secrets():
            text = text.replace(s, "***")
        return text


def get_settings() -> Settings:
    load_env()
    s = Settings(
        host=os.getenv("HOST", "127.0.0.1"),
        port=int(os.getenv("PORT", "8000")),
        payout=float(os.getenv("PAYOUT", "0.85")),
        allow_unvalidated=_flag("ALLOW_UNVALIDATED"),
        min_confluence=int(os.getenv("MIN_CONFLUENCE", "0")),
        seed_candles=int(os.getenv("SEED_CANDLES", "3000")),
        max_signal_age_s=float(os.getenv("MAX_SIGNAL_AGE_S", "20")),
        forex_provider=os.getenv("FOREX_PROVIDER", "").strip().lower(),
        forex_symbols=_list("FOREX_SYMBOLS", "EURUSD,GBPUSD,USDJPY,AUDUSD,USDCAD,USDCHF,NZDUSD,EURGBP,EURJPY,GBPJPY"),
        oanda_token=os.getenv("OANDA_TOKEN", ""),
        oanda_account=os.getenv("OANDA_ACCOUNT", ""),
        oanda_env=os.getenv("OANDA_ENV", "practice").strip().lower(),
        twelvedata_key=os.getenv("TWELVEDATA_KEY", ""),
        twelvedata_poll_s=float(os.getenv("TWELVEDATA_POLL_S", "15")),
        enable_demo=_flag("ENABLE_DEMO"),
    )
    for b in BROKERS:
        ssid = os.getenv(f"{b.upper()}_SSID", "").strip()
        if ssid:
            s.broker_ssid[b] = ssid
            s.broker_symbols[b] = _list(f"{b.upper()}_SYMBOLS", "EURUSD,GBPUSD,USDJPY")
    s.data_dir.mkdir(parents=True, exist_ok=True)
    s.models_dir.mkdir(parents=True, exist_ok=True)
    return s
