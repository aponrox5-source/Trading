"""XGBoost + LightGBM + CatBoost ensemble with leak-free walk-forward validation.

Honesty rules baked into the pipeline:
  * time-ordered splits only (expanding window + embargo), never random
  * the decision threshold is chosen on out-of-fold predictions, then checked on an untouched hold-out
  * a bundle is only "validated" when the hold-out is also profitable after payout
  * the engine stays silent when no validated edge exists (unless ALLOW_UNVALIDATED=1)
"""
from __future__ import annotations

import time
import warnings
from dataclasses import dataclass, field
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import log_loss

from .features import FEATURE_COLS, build_features, confluence_votes, make_labels

warnings.filterwarnings("ignore", category=UserWarning)


# --------------------------------------------------------------------------- models
def make_models(seed: int = 7, fast: bool = False) -> tuple[dict, dict]:
    """Returns (models, backends). Missing libraries fall back to sklearn and say so in `backends`."""
    from sklearn.ensemble import HistGradientBoostingClassifier as HGB

    n = 60 if fast else 300
    models: dict = {}
    backends: dict = {}

    def fallback(name: str, depth: int, lr: float, l2: float):
        models[name] = HGB(max_iter=max(40, n - 50), learning_rate=lr, max_depth=depth, l2_regularization=l2, random_state=seed)
        backends[name] = "STAND-IN: sklearn HistGradientBoosting (real library not installed)"

    try:
        from xgboost import XGBClassifier

        models["xgboost"] = XGBClassifier(
            n_estimators=n, max_depth=4, learning_rate=0.03, subsample=0.8, colsample_bytree=0.8,
            min_child_weight=5, reg_lambda=2.0, eval_metric="logloss", n_jobs=-1, random_state=seed,
        )
        backends["xgboost"] = "xgboost"
    except ImportError:
        fallback("xgboost", 4, 0.04, 1.0)
    try:
        from lightgbm import LGBMClassifier

        models["lightgbm"] = LGBMClassifier(
            n_estimators=n, num_leaves=15, learning_rate=0.03, subsample=0.8, subsample_freq=1,
            colsample_bytree=0.8, min_child_samples=50, reg_lambda=2.0, n_jobs=-1, random_state=seed, verbose=-1,
        )
        backends["lightgbm"] = "lightgbm"
    except ImportError:
        fallback("lightgbm", 5, 0.03, 2.0)
    try:
        from catboost import CatBoostClassifier

        models["catboost"] = CatBoostClassifier(
            iterations=n, depth=5, learning_rate=0.03, l2_leaf_reg=5.0, random_seed=seed, verbose=0, thread_count=-1,
        )
        backends["catboost"] = "catboost"
    except ImportError:
        fallback("catboost", 3, 0.05, 5.0)
    return models, backends


def _fresh(models: dict):
    from sklearn.base import clone

    return {k: clone(m) for k, m in models.items()}


def _logit(p: np.ndarray) -> np.ndarray:
    p = np.clip(p, 1e-4, 1 - 1e-4)
    return np.log(p / (1 - p))


# --------------------------------------------------------------------------- stats
def _wilson_lower(wins: int, n: int, z: float) -> float:
    if n == 0:
        return 0.0
    p = wins / n
    d = 1 + z * z / n
    centre = p + z * z / (2 * n)
    adj = z * np.sqrt((p * (1 - p) + z * z / (4 * n)) / n)
    return float((centre - adj) / d)


def _stats(win: np.ndarray, payout: float) -> dict:
    n = int(len(win))
    base = {"n": n, "breakeven": 1 / (1 + payout)}
    if n == 0:
        return {**base, "win_rate": None, "ev": None, "wilson_low": None}
    w = int(win.sum())
    wr = w / n
    return {**base, "win_rate": wr, "ev": wr * payout - (1 - wr), "wilson_low": _wilson_lower(w, n, 1.64)}


# --------------------------------------------------------------------------- bundle
@dataclass
class Bundle:
    tf_s: int
    models: dict
    backends: dict
    calibrator: LogisticRegression
    threshold: float | None
    validated: bool
    payout: float
    atr_range: tuple[float, float]
    report: dict
    feature_cols: list = field(default_factory=lambda: list(FEATURE_COLS))
    trained_at: float = field(default_factory=time.time)

    def predict(self, X: pd.DataFrame) -> dict:
        P = np.column_stack([m.predict_proba(X[self.feature_cols])[:, 1] for m in self.models.values()])
        blend = P.mean(axis=1)
        side = np.where(blend >= 0.5, 1, -1)
        cal = self.calibrator.predict_proba(_logit(blend).reshape(-1, 1))[:, 1]
        conf = np.where(side > 0, cal, 1 - cal)
        agree = ((P > 0.5) == (blend[:, None] > 0.5)).all(axis=1)
        return {"P": P, "blend": blend, "side": side, "conf": conf, "agree": agree}

    def save(self, path: Path) -> None:
        joblib.dump(self, path)

    @staticmethod
    def load(path: Path) -> "Bundle":
        return joblib.load(path)

    def summary(self) -> dict:
        r = self.report
        return {
            "tf": self.tf_s, "threshold": self.threshold, "validated": self.validated,
            "backends": self.backends, "trained_at": self.trained_at,
            "oof": r.get("oof"), "holdout": r.get("holdout"), "n_rows": r.get("n_rows"),
            "symbols": r.get("symbols"), "verdict": r.get("verdict"),
        }


# --------------------------------------------------------------------------- training
def build_dataset(frames: dict[str, pd.DataFrame], tf_s: int) -> pd.DataFrame:
    parts = []
    for sym, df in frames.items():
        if len(df) < 400:
            continue
        df = df.sort_values("ts").drop_duplicates("ts").reset_index(drop=True)
        X = build_features(df, tf_s)
        y, valid = make_labels(df)
        X["y"] = y
        X["symbol"] = sym
        X = X[valid].dropna(subset=FEATURE_COLS)
        parts.append(X)
    if not parts:
        raise ValueError("Not enough candles: need at least ~400 per symbol (thousands for a trustworthy model).")
    return pd.concat(parts, ignore_index=True).sort_values("ts", kind="stable").reset_index(drop=True)


def walk_forward(data: pd.DataFrame, models: dict, n_splits: int, embargo_rows: int) -> dict[str, np.ndarray]:
    n = len(data)
    start = int(n * 0.4)
    fold = (n - start) // n_splits
    X = data[FEATURE_COLS]
    y = data["y"].to_numpy()
    oof = {k: np.full(n, np.nan) for k in models}
    for k in range(n_splits):
        tr_end = start + k * fold
        te_start = tr_end + embargo_rows
        te_end = n if k == n_splits - 1 else start + (k + 1) * fold
        if te_start >= te_end:
            continue
        fm = _fresh(models)
        for name, m in fm.items():
            m.fit(X.iloc[:tr_end], y[:tr_end])
            oof[name][te_start:te_end] = m.predict_proba(X.iloc[te_start:te_end])[:, 1]
    return oof


def _select_threshold(conf, agree, win, payout, min_n):
    best = None
    for th in np.arange(0.52, 0.78, 0.01):
        m = agree & (conf >= th)
        if m.sum() < min_n:
            continue
        st = _stats(win[m], payout)
        profit = st["n"] * st["ev"]
        if st["ev"] > 0 and (best is None or profit > best[1]):
            best = (float(round(th, 2)), profit)
    return best[0] if best else None


def train_group(
    frames: dict[str, pd.DataFrame], tf_s: int, payout: float = 0.85, fast: bool = False,
    seed: int = 7, holdout_frac: float = 0.15, n_splits: int = 5, log=print,
) -> Bundle:
    data = build_dataset(frames, tf_s)
    n = len(data)
    if n < 2000:
        raise ValueError(f"Only {n} usable rows; need at least 2000 (ideally 50k+) to train something meaningful.")
    n_sym = data["symbol"].nunique()
    cut = int(n * (1 - holdout_frac))
    train, hold = data.iloc[:cut].reset_index(drop=True), data.iloc[cut:].reset_index(drop=True)
    models, backends = make_models(seed, fast)
    log(f"[train] rows={n} symbols={n_sym} tf={tf_s}s backends={backends}")

    log("[train] walk-forward validation ...")
    oof = walk_forward(train, models, n_splits, embargo_rows=5 * n_sym)
    ok = ~np.isnan(next(iter(oof.values())))
    y_tr = train["y"].to_numpy()
    P_oof = np.column_stack([v[ok] for v in oof.values()])
    blend = P_oof.mean(axis=1)
    cal = LogisticRegression(C=1e6).fit(_logit(blend).reshape(-1, 1), y_tr[ok])
    calp = cal.predict_proba(_logit(blend).reshape(-1, 1))[:, 1]
    side = np.where(blend >= 0.5, 1, -1)
    conf = np.where(side > 0, calp, 1 - calp)
    agree = ((P_oof > 0.5) == (blend[:, None] > 0.5)).all(axis=1)
    win = (side > 0) == (y_tr[ok] == 1)

    min_n = max(150, int(0.01 * ok.sum()))
    th = _select_threshold(conf, agree, win, payout, min_n)
    report: dict = {
        "n_rows": n, "symbols": sorted(data["symbol"].unique().tolist()), "tf_s": tf_s, "payout": payout,
        "per_model_oof": {
            k: {"accuracy": float(((v[ok] > 0.5) == (y_tr[ok] == 1)).mean()), "logloss": float(log_loss(y_tr[ok], np.clip(v[ok], 1e-4, 1 - 1e-4)))}
            for k, v in oof.items()
        },
        "baseline_logloss": float(log_loss(y_tr[ok], np.full(ok.sum(), y_tr[ok].mean()))),
    }

    validated = False
    oof_stats = hold_stats = None
    if th is not None:
        m = agree & (conf >= th)
        oof_stats = _stats(win[m], payout)
        votes = confluence_votes(train[ok].reset_index(drop=True), side)
        report["confluence_oof"] = {
            str(k): _stats(win[m & (votes >= k)], payout) for k in range(0, 6)
        }

    log("[train] fitting final models on training span, checking on untouched hold-out ...")
    final = _fresh(models)
    for m_ in final.values():
        m_.fit(train[FEATURE_COLS], y_tr)
    tmp = Bundle(tf_s, final, backends, cal, th, False, payout, (0, 1), {})
    if th is not None and len(hold):
        pr = tmp.predict(hold)
        hm = pr["agree"] & (pr["conf"] >= th)
        hwin = (pr["side"][hm] > 0) == (hold["y"].to_numpy()[hm] == 1)
        hold_stats = _stats(hwin, payout)
        validated = bool(hold_stats["n"] >= 30 and hold_stats["ev"] is not None and hold_stats["ev"] > 0)
    report["oof"], report["holdout"] = oof_stats, hold_stats
    report["verdict"] = (
        "VALIDATED: profitable out-of-fold and on the untouched hold-out (still not a guarantee)." if validated
        else "NO VALIDATED EDGE: signals are suppressed unless ALLOW_UNVALIDATED=1." if th is not None
        else "NO EDGE FOUND: no threshold was profitable after payout."
    )
    log(f"[train] {report['verdict']}")

    log("[train] refitting on all data for deployment ...")
    deploy = _fresh(models)
    for m_ in deploy.values():
        m_.fit(data[FEATURE_COLS], data["y"].to_numpy())
    atr = data["atr_rel"].to_numpy()
    atr_range = (float(np.quantile(atr, 0.05)), float(np.quantile(atr, 0.95)))
    return Bundle(tf_s, deploy, backends, cal, th, validated, payout, atr_range, report)
