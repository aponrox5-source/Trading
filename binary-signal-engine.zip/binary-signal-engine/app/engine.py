"""Live engine: ticks -> forming/closed candles (1m + 5m) -> features -> ensemble -> signals -> outcome tracking."""
from __future__ import annotations

import asyncio
import time
from collections import deque
from concurrent.futures import ThreadPoolExecutor

import numpy as np
import pandas as pd

from .config import Settings
from .core import SECONDS_TF, Candle, resample_candles
from .features import FEATURE_COLS, build_features, confluence_votes
from .ml import Bundle
from .storage import Store

TFS = (60, 300)
WINDOW = {60: 800, 300: 600}  # candles fed to the feature builder at inference time
MIN_BARS = {60: 450, 300: 350}
KEEP = 3000


class Engine:
    def __init__(self, settings: Settings, bundles: dict[tuple[str, int], Bundle], store: Store, publish):
        self.s = settings
        self.bundles = bundles
        self.store = store
        self.publish = publish  # sync callable(event: dict), must never block
        self.closed: dict[tuple, deque] = {}
        self.forming: dict[tuple, Candle] = {}
        self.pending: dict[tuple, dict] = {}
        self.last_pub: dict[tuple, float] = {}
        self.last_tick: dict[tuple, float] = {}
        self.signals: deque = deque(maxlen=300)
        self.stats: dict[str, dict] = {}
        self.pool = ThreadPoolExecutor(max_workers=4, thread_name_prefix="infer")
        for sig in reversed(store.recent_signals(300)):
            self.signals.appendleft(sig)
        self._rebuild_stats()

    # ---------------------------------------------------------------- history
    def seed(self, group: str, symbol: str, candles_1m: list[Candle]) -> None:
        merged = {c.ts: c for c in self.closed.get((group, symbol, 60), [])}
        merged.update({c.ts: c for c in candles_1m})
        ordered = [merged[k] for k in sorted(merged)][-KEEP:]
        self.closed[(group, symbol, 60)] = deque(ordered, maxlen=KEEP)
        self.closed[(group, symbol, 300)] = deque(resample_candles(ordered, 300), maxlen=KEEP)
        for tf in TFS:
            self.forming.pop((group, symbol, tf), None)

    def candles(self, group: str, symbol: str, tf_s: int, n: int = 500) -> dict:
        key = (group, symbol, tf_s)
        hist = list(self.closed.get(key, []))[-n:]
        f = self.forming.get(key)
        return {"candles": [c.chart() for c in hist], "forming": f.chart() if f else None}

    # ---------------------------------------------------------------- ticks
    async def on_tick(self, group: str, symbol: str, ts: float, price: float) -> None:
        self.last_tick[(group, symbol)] = time.time()
        for tf in TFS:
            key = (group, symbol, tf)
            bucket = int(ts) // tf * tf
            cur = self.forming.get(key)
            if cur is not None and bucket < cur.ts:
                continue  # stale tick
            if cur is None or bucket > cur.ts:
                if cur is not None:
                    await self._on_closed(group, symbol, tf, cur)
                cur = Candle(bucket, price, price, price, price)
                self.forming[key] = cur
            else:
                cur.h = max(cur.h, price)
                cur.l = min(cur.l, price)
                cur.c = price
            now = time.monotonic()
            if now - self.last_pub.get(key, 0) >= 0.25:
                self.last_pub[key] = now
                self.publish({"type": "candle", "group": group, "symbol": symbol, "tf": SECONDS_TF[tf], "closed": False, "candle": cur.chart()})

    # ---------------------------------------------------------------- closed candle
    async def _on_closed(self, group: str, symbol: str, tf: int, c: Candle) -> None:
        key = (group, symbol, tf)
        hist = self.closed.setdefault(key, deque(maxlen=KEEP))
        if not hist or hist[-1].ts < c.ts:
            hist.append(c)
        self.publish({"type": "candle", "group": group, "symbol": symbol, "tf": SECONDS_TF[tf], "closed": True, "candle": c.chart()})
        if tf == 60:
            self.pool.submit(self.store.upsert, group, symbol, 60, [c])

        sig = self.pending.get(key)
        if sig and sig["entry_ts"] == c.ts:
            self._resolve(key, sig, c)

        bundle = self.bundles.get((group, tf))
        if bundle is None or len(hist) < MIN_BARS[tf]:
            return
        if bundle.threshold is None or not (bundle.validated or self.s.allow_unvalidated):
            return
        t0 = time.perf_counter()
        window = list(hist)[-WINDOW[tf]:]
        # Accuracy guards: no signal on stale data (e.g. after a reconnect) or across a hole in the candle series.
        if self.s.max_signal_age_s and time.time() - (c.ts + tf) > self.s.max_signal_age_s:
            return
        recent = window[-61:]
        if any(b.ts - a.ts != tf for a, b in zip(recent, recent[1:])) or window[-1].ts != c.ts:
            return
        loop = asyncio.get_running_loop()
        out = await loop.run_in_executor(self.pool, self._infer, bundle, window, tf)
        if out is None:
            return
        out["latency_ms"] = round((time.perf_counter() - t0) * 1000, 1)
        self._emit(key, group, symbol, tf, c, bundle, out)

    def _infer(self, bundle: Bundle, window: list[Candle], tf: int) -> dict | None:
        df = pd.DataFrame({"ts": [c.ts for c in window], "o": [c.o for c in window], "h": [c.h for c in window], "l": [c.l for c in window], "c": [c.c for c in window]})
        X = build_features(df, tf).iloc[[-1]]
        if X[FEATURE_COLS].isna().any(axis=None):
            return None
        pr = bundle.predict(X)
        side, conf = int(pr["side"][0]), float(pr["conf"][0])
        lo, hi = bundle.atr_range
        atr_rel = float(X["atr_rel"].iloc[0])
        votes = int(confluence_votes(X, pr["side"])[0])
        reasons = []
        if not bool(pr["agree"][0]):
            reasons.append("models disagree")
        if conf < (bundle.threshold or 1):
            reasons.append("confidence below threshold")
        if not (lo <= atr_rel <= hi):
            reasons.append("volatility outside trained range")
        if float(X["range_atr"].iloc[0]) > 3.0:
            reasons.append("spike candle")
        if votes < self.s.min_confluence:
            reasons.append("indicator confluence too low")
        if reasons:
            return None
        return {
            "side": side, "conf": conf, "votes": votes,
            "models": {k: float(p) for k, p in zip(bundle.models.keys(), pr["P"][0])},
            "ind": {k: round(float(X[k].iloc[0]), 3) for k in ("rsi14", "ema_9_21", "macd_hist", "bb_pctb", "h_ema_9_21", "atr_rel")},
        }

    def _emit(self, key, group, symbol, tf, c: Candle, bundle: Bundle, out: dict) -> None:
        sig = {
            "id": f"{group}:{symbol}:{tf}:{c.ts}", "group": group, "symbol": symbol, "tf": SECONDS_TF[tf],
            "direction": "CALL" if out["side"] > 0 else "PUT", "confidence": round(out["conf"], 4),
            "models": {k: round(v, 4) for k, v in out["models"].items()}, "votes": out["votes"], "indicators": out["ind"],
            "signal_candle_ts": c.ts, "entry_ts": c.ts + tf, "expiry_ts": c.ts + 2 * tf, "price": c.c,
            "created_at": time.time(), "latency_ms": out["latency_ms"], "validated": bundle.validated,
            "status": "pending", "result": None,
            # Non-repaint: generated once, from a CLOSED candle only. Direction/confidence/entry never change afterwards;
            # only status/result/close fields are added when the trade candle finishes.
            "locked": True,
        }
        self.pending[key] = sig
        self.signals.appendleft(sig)
        self.pool.submit(self.store.save_signal, dict(sig))
        self.publish({"type": "signal", "signal": sig})

    def _resolve(self, key, sig: dict, c: Candle) -> None:
        """Outcome = trade candle close vs its open (a candle-aligned expiry; your manual entry delay will differ)."""
        if c.c > c.o:
            went = "CALL"
        elif c.c < c.o:
            went = "PUT"
        else:
            went = None
        sig["entry_price"], sig["close_price"] = c.o, c.c
        sig["result"] = "tie" if went is None else ("win" if went == sig["direction"] else "loss")
        sig["status"] = "closed"
        self.pending.pop(key, None)
        self.pool.submit(self.store.save_signal, dict(sig))
        self._rebuild_stats()
        self.publish({"type": "signal_result", "signal": sig, "stats": self.stats})

    def _rebuild_stats(self) -> None:
        st: dict[str, dict] = {}
        for sig in self.signals:
            if sig.get("result") not in ("win", "loss", "tie"):
                continue
            for k in ("all", f"{sig['group']}:{sig['tf']}"):
                d = st.setdefault(k, {"win": 0, "loss": 0, "tie": 0})
                d[sig["result"]] += 1
        for d in st.values():
            n = d["win"] + d["loss"]
            d["win_rate"] = d["win"] / n if n else None
            d["ev"] = (d["win"] * self.s.payout - d["loss"]) / n if n else None
        self.stats = st
