import asyncio
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.config import Settings
from app.core import Candle, resample_candles
from app.engine import Engine
from app.features import FEATURE_COLS, build_features
from app.ml import train_group
from app.sources.brokers import PocketOptionSource, _ReadOnlyClient, assert_read_only
from app.sources.synthetic import generate_candles


def frame(cs):
    return pd.DataFrame({"ts": [c.ts for c in cs], "o": [c.o for c in cs], "h": [c.h for c in cs], "l": [c.l for c in cs], "c": [c.c for c in cs]})


@pytest.mark.parametrize("tf_s,step", [(60, 60), (300, 300)])
def test_features_have_no_lookahead(tf_s, step):
    """Features at row i computed from the full history must equal features computed from data cut at row i."""
    df = frame(generate_candles(1500, seed=3, step=step, start_ts=1_700_000_000 // step * step))
    full = build_features(df, tf_s)
    for i in (700, 911, 1203, 1499):
        cut = build_features(df.iloc[: i + 1], tf_s).iloc[-1]
        a, b = full.iloc[i][FEATURE_COLS].astype(float), cut[FEATURE_COLS].astype(float)
        assert np.allclose(a.to_numpy(), b.to_numpy(), rtol=1e-7, atol=1e-9, equal_nan=True), (i, (a - b).abs().idxmax())


def test_tick_aggregation_and_closing():
    out = []
    eng = Engine(Settings(), {}, _FakeStore(), out.append)
    base = 1_700_000_040  # 60 divides it
    base -= base % 300

    async def run():
        for dt, px in [(1, 1.0), (10, 1.5), (30, 0.8), (59, 1.2), (61, 1.3)]:
            await eng.on_tick("g", "X", base + dt, px)

    asyncio.run(run())
    closed = [e for e in out if e["type"] == "candle" and e["closed"] and e["tf"] == "1m"]
    assert len(closed) == 1
    c = closed[0]["candle"]
    assert (c["open"], c["high"], c["low"], c["close"]) == (1.0, 1.5, 0.8, 1.2)
    f = eng.forming[("g", "X", 300)]
    assert (f.o, f.h, f.l, f.c) == (1.0, 1.5, 0.8, 1.3)


def test_resample_only_complete_buckets():
    cs = generate_candles(12, seed=1, start_ts=300 * 1000)
    out = resample_candles(cs, 300)
    assert len(out) == 2  # 12 minutes -> two complete 5m buckets, the 2-candle remainder is dropped
    assert out[0].h == max(c.h for c in cs[:5]) and out[0].c == cs[4].c


def test_broker_adapters_are_read_only():
    assert_read_only(PocketOptionSource("42[\"auth\",{}]"))

    class Fake:
        def get_candles(self):
            return "ok"

        def buy(self):
            raise AssertionError("must never be reachable")

    ro = _ReadOnlyClient(Fake(), ("get_candles",))
    assert ro.get_candles() == "ok"
    with pytest.raises(PermissionError):
        ro.buy
    with pytest.raises(PermissionError):
        ro._c


def _frames(phi, n=14000):
    return {f"S{i}": frame(generate_candles(n, seed=40 + i, phi=phi, start_ts=1_700_000_000)) for i in range(2)}


def test_pipeline_finds_edge_in_predictable_market():
    b = train_group(_frames(phi=0.6), 60, payout=0.85, fast=True, log=lambda *_: None)
    assert b.threshold is not None and b.validated, b.report
    assert b.report["holdout"]["win_rate"] > 0.56


def test_pipeline_reports_no_edge_in_random_market():
    b = train_group(_frames(phi=0.0), 60, payout=0.85, fast=True, log=lambda *_: None)
    assert not b.validated, "random walk must not produce a validated edge"


class _FakeStore:
    def upsert(self, *a, **k):
        pass

    def save_signal(self, *a, **k):
        pass

    def recent_signals(self, *a, **k):
        return []


def test_engine_end_to_end_signal_and_resolution():
    """Train on a predictable synthetic market, then stream ticks through the live engine."""
    bundle = train_group(_frames(phi=0.6), 60, payout=0.85, fast=True, log=lambda *_: None)
    assert bundle.validated
    cs = generate_candles(1000, seed=77, phi=0.6, start_ts=1_700_000_000 // 60 * 60)
    seed, live = cs[:700], cs[700:]
    events = []
    eng = Engine(Settings(max_signal_age_s=0), {("demo", 60): bundle}, _FakeStore(), events.append)
    eng.seed("demo", "X", seed)

    async def run():
        for c in live:
            for dt, px in ((0, c.o), (15, c.h), (30, c.l), (59, c.c)):
                await eng.on_tick("demo", "X", c.ts + dt, px)

    asyncio.run(run())
    sigs = [e["signal"] for e in events if e["type"] == "signal"]
    res = [e["signal"] for e in events if e["type"] == "signal_result"]
    assert sigs, "engine should emit signals on a validated model"
    assert all(s["direction"] in ("CALL", "PUT") and 0.5 < s["confidence"] <= 1 for s in sigs)
    assert all(s["entry_ts"] == s["signal_candle_ts"] + 60 for s in sigs)
    assert res and all(r["result"] in ("win", "loss", "tie") for r in res)
    assert max(s["latency_ms"] for s in sigs) < 1000
    wins = sum(r["result"] == "win" for r in res)
    print(f"signals={len(sigs)} resolved={len(res)} wins={wins} max_latency_ms={max(s['latency_ms'] for s in sigs)}")


def _run_engine(bundle, candles_seed, candles_live):
    events = []
    eng = Engine(Settings(max_signal_age_s=0), {("demo", 60): bundle}, _FakeStore(), events.append)
    eng.seed("demo", "X", candles_seed)

    async def run():
        for c in candles_live:
            for dt, px in ((0, c.o), (15, c.h), (30, c.l), (59, c.c)):
                await eng.on_tick("demo", "X", c.ts + dt, px)

    asyncio.run(run())
    return [e["signal"] for e in events if e["type"] == "signal"], [e["signal"] for e in events if e["type"] == "signal_result"]


def _core(s):
    keys = ("id", "direction", "confidence", "models", "entry_ts", "expiry_ts", "price", "signal_candle_ts", "locked")
    return {k: s[k] for k in keys}


def test_signals_never_repaint():
    """1) Appending future candles never changes an earlier signal. 2) Resolving a trade never edits a signal's core fields."""
    bundle = train_group(_frames(phi=0.6), 60, payout=0.85, fast=True, log=lambda *_: None)
    cs = generate_candles(1000, seed=91, phi=0.6, start_ts=1_700_000_000 // 60 * 60)
    seed, live = cs[:700], cs[700:]
    short, _ = _run_engine(bundle, seed, live[:120])
    longer, res = _run_engine(bundle, seed, live)
    assert short, "need signals to compare"
    by_id = {s["id"]: _core(s) for s in longer}
    for s in short:
        assert by_id[s["id"]] == _core(s), "a past signal changed when later data arrived (repaint)"
    # replay determinism
    again, _ = _run_engine(bundle, seed, live)
    assert [_core(s) for s in again] == [_core(s) for s in longer]
    # outcome tracking only adds result fields
    for r in res:
        assert r["locked"] and r["result"] in ("win", "loss", "tie")


def test_no_signal_across_data_gap_or_stale_candle():
    bundle = train_group(_frames(phi=0.6), 60, payout=0.85, fast=True, log=lambda *_: None)
    cs = generate_candles(900, seed=5, phi=0.6, start_ts=1_700_000_000 // 60 * 60)
    seed, live = cs[:700], cs[700:]
    live = live[:30] + live[40:]  # ten missing minutes
    sigs, _ = _run_engine(bundle, seed, live)
    gap_ts = cs[730].ts
    resume = cs[740].ts
    # no signal on any candle whose previous 60 candles contain the hole
    assert all(not (gap_ts <= s["signal_candle_ts"] < resume + 60 * 60) for s in sigs)
    assert any(s["signal_candle_ts"] < gap_ts for s in sigs) and any(s["signal_candle_ts"] >= resume + 60 * 60 for s in sigs), "signals must resume once the hole has left the window"
    # stale guard: ticks stamped years ago produce nothing when the age limit is on
    events = []
    eng = Engine(Settings(max_signal_age_s=20), {("demo", 60): bundle}, _FakeStore(), events.append)
    eng.seed("demo", "X", seed)

    async def run():
        for c in live[:60]:
            await eng.on_tick("demo", "X", c.ts + 5, c.c)

    asyncio.run(run())
    assert not [e for e in events if e["type"] == "signal"]


def test_runtime_goes_live_and_streams_candles(tmp_path):
    """Whole live runtime (history -> reconnect loop -> engine -> hub) against the synthetic source."""
    from app.runtime import Runtime
    from app.sources.synthetic import SyntheticSource

    s = Settings(data_dir=tmp_path, models_dir=tmp_path)
    rt = Runtime(s, sources=[("demo", SyntheticSource(), ["A", "B"])])
    q = asyncio.Queue()
    rt.hub.clients.add(q)

    async def run():
        rt.start()
        await asyncio.sleep(2.5)
        await rt.stop()

    asyncio.run(run())
    evs = []
    while not q.empty():
        evs.append(q.get_nowait())
    assert rt.status["demo"]["state"] == "live"
    assert any(e["type"] == "candle" and not e["closed"] and e["symbol"] == "A" for e in evs)
    snap = rt.engine.candles("demo", "A", 60, 500)
    assert len(snap["candles"]) >= 400 and snap["forming"] is not None
    assert len(rt.engine.candles("demo", "A", 300, 500)["candles"]) >= 80
