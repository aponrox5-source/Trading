"""Command line: collect / import-csv / train / demo-data / check-source / serve"""
from __future__ import annotations

import argparse
import asyncio
import sys
import time

import pandas as pd

from .config import get_settings
from .core import TF_SECONDS, Candle, resample_candles
from .storage import Store


async def _collect(args) -> None:
    from .sources import build_sources

    s = get_settings()
    srcs = {g: (src, syms) for g, src, syms in build_sources(s)}
    if args.group not in srcs:
        sys.exit(f"'{args.group}' is not configured in .env (configured: {list(srcs) or 'none'})")
    src, default_syms = srcs[args.group]
    store = Store(s.db_path)
    tf_s = TF_SECONDS[args.tf]
    for sym in (args.symbols.split(",") if args.symbols else default_syms):
        got, end = 0, None
        while got < args.count:
            try:
                batch = await src.history(sym, tf_s, min(5000, args.count - got), end)
            except Exception as e:  # noqa: BLE001
                print(f"{sym}: {s.redact(str(e))}")
                break
            if not batch:
                break
            store.upsert(args.group, sym, tf_s, batch)
            got += len(batch)
            new_end = batch[0].ts
            if end is not None and new_end >= end:
                break
            end = new_end
        print(f"{sym}: stored {got} x {args.tf} candles")
    await src.close()


def _import_csv(args) -> None:
    s = get_settings()
    df = pd.read_csv(args.file)
    df.columns = [c.strip().lower() for c in df.columns]
    ren = {"time": "ts", "timestamp": "ts", "date": "ts", "open": "o", "high": "h", "low": "l", "close": "c", "volume": "v"}
    df = df.rename(columns=ren)
    if not pd.api.types.is_numeric_dtype(df["ts"]):
        df["ts"] = (pd.to_datetime(df["ts"], utc=True) - pd.Timestamp("1970-01-01", tz="UTC")) // pd.Timedelta(seconds=1)
    if df["ts"].max() > 1e11:
        df["ts"] = df["ts"] // 1000
    if "v" not in df:
        df["v"] = 0.0
    candles = [Candle(int(r.ts), float(r.o), float(r.h), float(r.l), float(r.c), float(r.v)) for r in df.sort_values("ts").itertuples()]
    store = Store(s.db_path)
    tf_s = TF_SECONDS[args.tf]
    store.upsert(args.group, args.symbol, tf_s, candles)
    if tf_s == 60:
        store.upsert(args.group, args.symbol, 300, resample_candles(candles, 300))
    print(f"imported {len(candles)} candles into {args.group}/{args.symbol}/{args.tf}")


def _train(args) -> None:
    from .ml import train_group

    s = get_settings()
    store = Store(s.db_path)
    tf_s = TF_SECONDS[args.tf]
    syms = store.symbols(args.group, tf_s)
    if not syms and tf_s == 300:  # build 5m from stored 1m
        for sym in store.symbols(args.group, 60):
            store.upsert(args.group, sym, 300, resample_candles(store.load_candles(args.group, sym, 60), 300))
        syms = store.symbols(args.group, 300)
    if not syms:
        sys.exit(f"No stored {args.tf} candles for '{args.group}'. Run collect / import-csv / demo-data first.")
    frames = {sym: store.load(args.group, sym, tf_s) for sym in syms}
    bundle = train_group(frames, tf_s, payout=s.payout, fast=args.fast)
    path = s.models_dir / f"{args.group}_{args.tf}.joblib"
    bundle.save(path)
    r = bundle.report
    print("\n=== REPORT ===")
    print(r["verdict"])
    print("backends   :", bundle.backends)
    print("breakeven  :", f"{1 / (1 + s.payout):.1%} win rate needed at payout {s.payout:.0%}")
    print("threshold  :", bundle.threshold)
    print("out-of-fold:", r.get("oof"))
    print("hold-out   :", r.get("holdout"))
    print("saved      :", path)


def _demo_data(args) -> None:
    from .sources.synthetic import generate_candles

    s = get_settings()
    store = Store(s.db_path)
    for i, sym in enumerate(args.symbols.split(",")):
        cs = generate_candles(args.n, seed=100 + i, phi=args.phi, start_ts=int(time.time()) // 60 * 60 - args.n * 60)
        store.upsert("demo", sym, 60, cs)
        store.upsert("demo", sym, 300, resample_candles(cs, 300))
    print(f"wrote synthetic candles (phi={args.phi}) to group 'demo'. These are NOT real prices.")


async def _check(args) -> None:
    from .sources import build_sources
    from .sources.brokers import assert_read_only

    s = get_settings()
    for g, src, syms in build_sources(s):
        if g != args.group:
            continue
        assert_read_only(src)
        print(f"{g}: read-only guard OK; fetching 5 x 1m candles for {syms[0]} ...")
        cs = await src.history(syms[0], 60, 5)
        for c in cs:
            print(" ", c)
        print("tick stream (10 s) ...")
        n = 0
        t0 = time.time()
        async for sym, ts, price in src.stream(syms[:1]):
            n += 1
            if n <= 3:
                print(" ", sym, ts, price)
            if time.time() - t0 > 10:
                break
        print(f"received {n} ticks")
        await src.close()
        return
    sys.exit(f"'{args.group}' is not configured in .env")


def main() -> None:
    p = argparse.ArgumentParser(prog="app.cli")
    sub = p.add_subparsers(dest="cmd", required=True)
    a = sub.add_parser("collect")
    a.add_argument("--group", default="forex")
    a.add_argument("--symbols", default="")
    a.add_argument("--tf", default="1m", choices=TF_SECONDS)
    a.add_argument("--count", type=int, default=20000)
    a = sub.add_parser("import-csv")
    a.add_argument("--group", required=True)
    a.add_argument("--symbol", required=True)
    a.add_argument("--tf", default="1m", choices=TF_SECONDS)
    a.add_argument("--file", required=True)
    a = sub.add_parser("train")
    a.add_argument("--group", required=True)
    a.add_argument("--tf", default="1m", choices=TF_SECONDS)
    a.add_argument("--fast", action="store_true")
    a = sub.add_parser("demo-data")
    a.add_argument("--symbols", default="DEMO1,DEMO2,DEMO3")
    a.add_argument("--n", type=int, default=30000)
    a.add_argument("--phi", type=float, default=0.0)
    a = sub.add_parser("check-source")
    a.add_argument("group")
    sub.add_parser("serve")
    args = p.parse_args()

    if args.cmd == "collect":
        asyncio.run(_collect(args))
    elif args.cmd == "import-csv":
        _import_csv(args)
    elif args.cmd == "train":
        _train(args)
    elif args.cmd == "demo-data":
        _demo_data(args)
    elif args.cmd == "check-source":
        asyncio.run(_check(args))
    elif args.cmd == "serve":
        import uvicorn

        s = get_settings()
        uvicorn.run("app.server:app", host=s.host, port=s.port, log_level="info")


if __name__ == "__main__":
    main()
