from __future__ import annotations

from ..config import Settings
from .base import CandleSource


def build_sources(s: Settings) -> list[tuple[str, CandleSource, list[str]]]:
    """Returns [(group, source, symbols)] for everything configured in .env."""
    out: list[tuple[str, CandleSource, list[str]]] = []
    if s.forex_provider == "oanda" and s.oanda_token and s.oanda_account:
        from .forex import OandaSource

        out.append(("forex", OandaSource(s.oanda_token, s.oanda_account, s.oanda_env), s.forex_symbols))
    elif s.forex_provider == "twelvedata" and s.twelvedata_key:
        from .forex import TwelveDataSource

        out.append(("forex", TwelveDataSource(s.twelvedata_key, s.twelvedata_poll_s), s.forex_symbols))
    from .brokers import BROKER_CLASSES

    for name, ssid in s.broker_ssid.items():
        try:
            out.append((name, BROKER_CLASSES[name](ssid), s.broker_symbols[name]))
        except NotImplementedError as e:
            print(f"[sources] {name}: {e}")
    if s.enable_demo:
        from .synthetic import SyntheticSource

        out.append(("demo", SyntheticSource(), ["DEMO1", "DEMO2", "DEMO3"]))
    return out
