"""Source interface + shared HTTP/stream helpers (stdlib only, so nothing extra to install)."""
from __future__ import annotations

import asyncio
import threading
import urllib.request
from abc import ABC, abstractmethod
from typing import AsyncIterator

from ..core import Candle

Tick = tuple[str, float, float]  # (symbol, epoch seconds, price)


class CandleSource(ABC):
    group: str = ""

    @abstractmethod
    async def history(self, symbol: str, tf_s: int, count: int, end_ts: int | None = None) -> list[Candle]:
        """Up to `count` COMPLETE candles ending before end_ts (default: now), oldest first."""

    @abstractmethod
    def stream(self, symbols: list[str]) -> AsyncIterator[Tick]:
        """Async generator of live ticks. Raises on disconnect (the runner reconnects)."""

    async def close(self) -> None:  # pragma: no cover
        return None


def http_get(url: str, headers: dict | None = None, timeout: float = 20) -> bytes:
    req = urllib.request.Request(url, headers=headers or {})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


async def aio_get(url: str, headers: dict | None = None, timeout: float = 20) -> bytes:
    return await asyncio.to_thread(http_get, url, headers, timeout)


async def line_stream(url: str, headers: dict, parse) -> AsyncIterator:
    """Read a chunked HTTP stream in a worker thread; `parse(line_bytes)` yields zero or more items."""
    loop = asyncio.get_running_loop()
    q: asyncio.Queue = asyncio.Queue(maxsize=20000)
    stop = threading.Event()

    def put(item):
        try:
            q.put_nowait(item)
        except asyncio.QueueFull:
            pass

    def reader():
        try:
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=45) as r:
                for line in r:
                    if stop.is_set():
                        return
                    for item in parse(line):
                        loop.call_soon_threadsafe(put, item)
        except Exception as e:  # noqa: BLE001
            loop.call_soon_threadsafe(put, e)
        finally:
            loop.call_soon_threadsafe(put, None)

    threading.Thread(target=reader, daemon=True, name="stream-reader").start()
    try:
        while True:
            item = await q.get()
            if item is None:
                raise ConnectionError("stream closed by server")
            if isinstance(item, Exception):
                raise item
            yield item
    finally:
        stop.set()
