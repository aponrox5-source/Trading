"""Live runtime (no web framework needed, so it is fully testable): sources -> engine -> hub."""
from __future__ import annotations

import asyncio
import time

from .config import Settings
from .core import SECONDS_TF, TF_SECONDS
from .engine import Engine
from .ml import Bundle
from .sources import build_sources
from .storage import Store


class Hub:
    """Fan-out to dashboards. Slow clients drop their oldest event instead of slowing everyone down."""

    def __init__(self):
        self.clients: set[asyncio.Queue] = set()

    def publish(self, ev: dict) -> None:
        for q in list(self.clients):
            if q.full():
                try:
                    q.get_nowait()
                except asyncio.QueueEmpty:
                    pass
            q.put_nowait(ev)


class Runtime:
    def __init__(self, s: Settings, sources: list | None = None):
        self.s = s
        self.hub = Hub()
        self.store = Store(s.db_path)
        self.bundles = self._load_bundles()
        self.engine = Engine(s, self.bundles, self.store, self.hub.publish)
        self.sources = build_sources(s) if sources is None else sources
        self.status: dict[str, dict] = {g: {"state": "starting", "symbols": syms} for g, _src, syms in self.sources}
        self.tasks: list[asyncio.Task] = []

    def _load_bundles(self) -> dict:
        out = {}
        for p in self.s.models_dir.glob("*.joblib"):
            group, _, tf = p.stem.rpartition("_")
            if tf in TF_SECONDS:
                try:
                    out[(group, TF_SECONDS[tf])] = Bundle.load(p)
                except Exception as e:  # noqa: BLE001
                    print(f"[models] could not load {p.name}: {type(e).__name__}")
        return out

    def start(self) -> None:
        for group, src, syms in self.sources:
            self.tasks.append(asyncio.create_task(self.run_source(group, src, syms)))

    async def stop(self) -> None:
        for t in self.tasks:
            t.cancel()
        await asyncio.gather(*self.tasks, return_exceptions=True)
        for _g, src, _s in self.sources:
            await src.close()

    def set_status(self, group: str, state: str) -> None:
        self.status[group]["state"] = state
        self.status[group]["since"] = time.time()
        self.hub.publish({"type": "status", "status": self.status})

    async def seed(self, group: str, source, symbol: str) -> None:
        candles = self.store.load_candles(group, symbol, 60, self.s.seed_candles)
        try:
            fresh = await source.history(symbol, 60, min(self.s.seed_candles, 1500))
            self.store.upsert(group, symbol, 60, fresh)
            candles = sorted({c.ts: c for c in [*candles, *fresh]}.values(), key=lambda c: c.ts)
        except Exception as e:  # noqa: BLE001
            print(f"[{group}] history failed for {symbol}: {self.s.redact(type(e).__name__ + ': ' + str(e))}")
        self.engine.seed(group, symbol, candles)

    async def run_source(self, group: str, source, symbols: list[str]) -> None:
        backoff = 1.0
        while True:
            try:
                self.set_status(group, "loading history")
                for sym in symbols:
                    await self.seed(group, source, sym)
                self.set_status(group, "live")
                backoff = 1.0
                async for sym, ts, price in source.stream(symbols):
                    await self.engine.on_tick(group, sym, ts, price)
                raise ConnectionError("stream ended")
            except asyncio.CancelledError:
                raise
            except Exception as e:  # noqa: BLE001
                msg = self.s.redact(f"{type(e).__name__}: {e}")[:160]
                print(f"[{group}] {msg}; retry in {backoff:.0f}s")
                self.set_status(group, f"reconnecting ({msg})")
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2, 30)

    def overview(self) -> dict:
        models = {f"{g}_{SECONDS_TF[tf]}": b.summary() for (g, tf), b in self.bundles.items()}
        syms = {g: sy for g, _src, sy in self.sources}
        return {"status": self.status, "symbols": syms, "models": models, "stats": self.engine.stats,
                "payout": self.s.payout, "allow_unvalidated": self.s.allow_unvalidated}
