"""Feature engineering. Every feature at row t uses only candles that were CLOSED at time t+tf.

All price-based features are divided by ATR so one model can learn from many symbols.
Higher-timeframe (HTF) features come from the 5m (for 1m) or 15m (for 5m) series and are aligned
with merge_asof on bar CLOSE time, so a higher-timeframe bar is never used before it has finished.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

HTF_MINUTES = {60: 5, 300: 15}
BASE_COLS = [
    "ret1", "ret2", "ret3", "ret5", "ret10",
    "rsi14", "rsi7", "rsi_slope", "macd_hist", "ema_9_21", "ema_21_50", "px_ema21",
    "bb_pctb", "bb_width", "stoch_k", "body", "upper_wick", "lower_wick", "range_atr",
    "streak", "atr_rel", "atr_ratio", "hour_sin", "hour_cos",
]
HTF_COLS = ["h_rsi14", "h_ema_9_21", "h_macd_hist", "h_ret1", "h_stoch_k"]
FEATURE_COLS = BASE_COLS + HTF_COLS


def _ema(s: pd.Series, n: int) -> pd.Series:
    return s.ewm(span=n, adjust=False).mean()


def _rsi(c: pd.Series, n: int) -> pd.Series:
    d = c.diff()
    up = d.clip(lower=0)
    dn = (-d).clip(lower=0)
    ru = up.ewm(alpha=1 / n, adjust=False, min_periods=n).mean()
    rd = dn.ewm(alpha=1 / n, adjust=False, min_periods=n).mean()
    with np.errstate(divide="ignore", invalid="ignore"):
        rsi = 100 - 100 / (1 + ru / rd)
    flat = (ru == 0) & (rd == 0)
    return rsi.where(~flat, 50.0)


def _core(df: pd.DataFrame) -> pd.DataFrame:
    o, h, l, c = df["o"], df["h"], df["l"], df["c"]
    pc = c.shift(1)
    tr = pd.concat([h - l, (h - pc).abs(), (l - pc).abs()], axis=1).max(axis=1)
    atr = tr.ewm(alpha=1 / 14, adjust=False, min_periods=14).mean()
    atr = atr.where(atr > 0)

    out = pd.DataFrame(index=df.index)
    for k in (1, 2, 3, 5, 10):
        out[f"ret{k}"] = (c - c.shift(k)) / atr
    out["rsi14"] = _rsi(c, 14)
    out["rsi7"] = _rsi(c, 7)
    out["rsi_slope"] = out["rsi14"].diff(3)
    macd = _ema(c, 12) - _ema(c, 26)
    out["macd_hist"] = (macd - _ema(macd, 9)) / atr
    e9, e21, e50 = _ema(c, 9), _ema(c, 21), _ema(c, 50)
    out["ema_9_21"] = (e9 - e21) / atr
    out["ema_21_50"] = (e21 - e50) / atr
    out["px_ema21"] = (c - e21) / atr
    m20 = c.rolling(20).mean()
    sd = c.rolling(20).std()
    out["bb_pctb"] = ((c - (m20 - 2 * sd)) / (4 * sd)).where(sd > 0, 0.5)
    out["bb_width"] = (4 * sd) / atr
    ll, hh = l.rolling(14).min(), h.rolling(14).max()
    out["stoch_k"] = ((c - ll) / (hh - ll)).where((hh - ll) > 0, 0.5)
    out["body"] = (c - o) / atr
    out["upper_wick"] = (h - np.maximum(o, c)) / atr
    out["lower_wick"] = (np.minimum(o, c) - l) / atr
    out["range_atr"] = (h - l) / atr
    sgn = np.sign(c.diff()).fillna(0)
    run = (sgn != sgn.shift()).cumsum()
    out["streak"] = sgn * (sgn.groupby(run).cumcount() + 1)
    rel = atr / c
    out["atr_rel"] = rel
    out["atr_ratio"] = rel / rel.rolling(100, min_periods=100).mean()
    return out


def _epoch(idx: pd.DatetimeIndex) -> np.ndarray:
    return ((idx - pd.Timestamp("1970-01-01", tz="UTC")) // pd.Timedelta(seconds=1)).to_numpy(dtype="int64")


def _htf(df: pd.DataFrame, tf_s: int) -> pd.DataFrame:
    minutes = HTF_MINUTES[tf_s]
    idx = pd.to_datetime(df["ts"].to_numpy(dtype="int64"), unit="s", utc=True)
    r = (
        df[["o", "h", "l", "c"]]
        .set_axis(idx)
        .resample(f"{minutes}min", label="left", closed="left")
        .agg({"o": "first", "h": "max", "l": "min", "c": "last"})
        .dropna()
    )
    core = _core(r)
    right = pd.DataFrame(
        {
            "close_ts": _epoch(r.index) + minutes * 60,
            "h_rsi14": core["rsi14"].to_numpy(),
            "h_ema_9_21": core["ema_9_21"].to_numpy(),
            "h_macd_hist": core["macd_hist"].to_numpy(),
            "h_ret1": core["ret1"].to_numpy(),
            "h_stoch_k": core["stoch_k"].to_numpy(),
        }
    ).sort_values("close_ts")
    left = pd.DataFrame({"close_ts": df["ts"].to_numpy(dtype="int64") + tf_s})
    merged = pd.merge_asof(left, right, on="close_ts", direction="backward")
    return merged[HTF_COLS]


def build_features(df: pd.DataFrame, tf_s: int) -> pd.DataFrame:
    """df columns: ts(open time, epoch s), o, h, l, c. Returns ts, close + FEATURE_COLS (NaN during warm-up)."""
    df = df.reset_index(drop=True)
    core = _core(df)
    hour = (df["ts"].to_numpy(dtype="int64") % 86400) / 3600.0
    core["hour_sin"] = np.sin(2 * np.pi * hour / 24)
    core["hour_cos"] = np.cos(2 * np.pi * hour / 24)
    X = pd.concat([core[BASE_COLS], _htf(df, tf_s)], axis=1)
    X.insert(0, "ts", df["ts"].to_numpy(dtype="int64"))
    X["close"] = df["c"].to_numpy()
    return X.replace([np.inf, -np.inf], np.nan)


def make_labels(df: pd.DataFrame) -> tuple[np.ndarray, np.ndarray]:
    """Label = does the NEXT candle close above its open (~ this close)? Returns (y, valid). Ties are invalid."""
    c = df["c"].to_numpy()
    nxt = np.append(c[1:], np.nan)
    valid = ~np.isnan(nxt) & (nxt != c)
    y = (nxt > c).astype(int)
    return y, valid


def confluence_votes(X: pd.DataFrame, side: np.ndarray) -> np.ndarray:
    """Simple indicator agreement count (0-5) for a proposed direction (side = +1 CALL / -1 PUT)."""
    s = np.asarray(side)
    v = (s * X["ema_9_21"].to_numpy() > 0).astype(int)
    v += (s * X["macd_hist"].to_numpy() > 0).astype(int)
    v += (s * X["h_ema_9_21"].to_numpy() > 0).astype(int)
    v += np.where(s > 0, X["rsi14"].to_numpy() < 70, X["rsi14"].to_numpy() > 30).astype(int)
    v += np.where(s > 0, X["bb_pctb"].to_numpy() < 0.9, X["bb_pctb"].to_numpy() > 0.1).astype(int)
    return v
