"""Synthetic market for demos and tests ONLY. Prices are random numbers, so a correct pipeline should find NO edge
(phi=0). Use phi>0 to create a deliberately predictable market to prove the pipeline can detect an edge."""
from __future__ import annotations

import asyncio
import time
from typing import AsyncIterator

import numpy as np

from ..core import Candle
from .base import CandleSource, Tick


def generate_candles(n: int, seed: int = 1, start_ts: int | None = None, step: int = 60,
                     price0: float = 1.1, sigma: float = 2e-4, phi: float = 0.0) -> list[Candle]:
    rng = np.random.default_rng(seed)
    start_ts = start_ts if start_ts is not None else (int(time.time()) // step * step - n * step)
    out: list[Candle] = []
    p, prev = price0, 0.0
    for i in range(n):
        steps = rng.normal(0, sigma / np.sqrt(8), 8) + phi * prev / 8
        path = p + np.cumsum(steps)
        c = float(path[-1])
        out.append(Candle(start_ts + i * step, p, float(max(p, path.max())), float(min(p, path.min())), c, 8.0))
        prev, p = c - p, c
    return out


class SyntheticSource(CandleSource):
    group = "demo"

    def __init__(self, seed: int = 11):
        self._seed = seed
        self._last: dict[str, float] = {}

    async def history(self, symbol: str, tf_s: int, count: int, end_ts: int | None = None) -> list[Candle]:
        cs = generate_candles(count, seed=self._seed + sum(map(ord, symbol)), step=60, price0=1.1 + 0.01 * (sum(map(ord, symbol)) % 7))
        self._last[symbol] = cs[-1].c
        return cs

    async def stream(self, symbols: list[str]) -> AsyncIterator[Tick]:
        rng = np.random.default_rng(self._seed)
        price = {s: self._last.get(s, 1.1) for s in symbols}
        while True:
            for s in symbols:
                price[s] += float(rng.normal(0, 4e-5))
                yield (s, time.time(), price[s])
            await asyncio.sleep(0.25)
