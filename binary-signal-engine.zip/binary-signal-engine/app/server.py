"""FastAPI app: REST + WebSocket for the dashboard. Run: python -m app.cli serve"""
from __future__ import annotations

import asyncio
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from .config import get_settings
from .core import TF_SECONDS
from .runtime import Runtime

STATIC = Path(__file__).parent / "static"


@asynccontextmanager
async def lifespan(app: FastAPI):
    rt = Runtime(get_settings())
    app.state.rt = rt
    if not rt.sources:
        print("[server] no sources configured - copy .env.example to .env and fill it in (or ENABLE_DEMO=1).")
    rt.start()
    yield
    await rt.stop()


app = FastAPI(title="Binary Signal Engine", lifespan=lifespan)


@app.get("/")
def index():
    return FileResponse(STATIC / "index.html")


@app.get("/api/overview")
def overview():
    return app.state.rt.overview()


@app.get("/api/candles")
def candles(group: str, symbol: str, tf: str = "1m", n: int = 500):
    return app.state.rt.engine.candles(group, symbol, TF_SECONDS.get(tf, 60), min(n, 1500))


@app.get("/api/signals")
def signals(limit: int = 100):
    return list(app.state.rt.engine.signals)[:limit]


@app.websocket("/ws")
async def ws(sock: WebSocket):
    await sock.accept()
    rt: Runtime = app.state.rt
    q: asyncio.Queue = asyncio.Queue(maxsize=2000)
    rt.hub.clients.add(q)
    try:
        await sock.send_json({"type": "hello", "overview": rt.overview()})
        while True:
            await sock.send_json(await q.get())
    except (WebSocketDisconnect, RuntimeError):
        pass
    finally:
        rt.hub.clients.discard(q)


app.mount("/static", StaticFiles(directory=STATIC), name="static")
