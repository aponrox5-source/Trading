"""Shared types and small helpers."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

TF_SECONDS = {"1m": 60, "5m": 300}
SECONDS_TF = {v: k for k, v in TF_SECONDS.items()}


@dataclass(slots=True)
class Candle:
    ts: int  # candle OPEN time, epoch seconds (UTC)
    o: float
    h: float
    l: float
    c: float
    v: float = 0.0

    def chart(self) -> dict:
        return {"time": self.ts, "open": self.o, "high": self.h, "low": self.l, "close": self.c}


def resample_candles(candles: Iterable[Candle], tf_s: int, base_s: int = 60) -> list[Candle]:
    """Aggregate base candles into tf_s candles. The last bucket is returned only if it is complete."""
    out: list[Candle] = []
    cur: Candle | None = None
    last_ts = None
    for c in candles:
        last_ts = c.ts
        b = c.ts // tf_s * tf_s
        if cur is None or cur.ts != b:
            if cur is not None:
                out.append(cur)
            cur = Candle(b, c.o, c.h, c.l, c.c, c.v)
        else:
            cur.h = max(cur.h, c.h)
            cur.l = min(cur.l, c.l)
            cur.c = c.c
            cur.v += c.v
    if cur is not None and last_ts is not None and last_ts + base_s >= cur.ts + tf_s:
        out.append(cur)
    return out
