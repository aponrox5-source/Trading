"""Forex providers. Pick one with FOREX_PROVIDER=oanda|twelvedata in .env.

OANDA (recommended): free practice account, real-time streaming prices -> accurate forming candles.
Twelve Data: REST polling; candle highs/lows are only as accurate as the poll rate (see README).
"""
from __future__ import annotations

import asyncio
import calendar
import json
import time
from datetime import datetime, timezone
from typing import AsyncIterator
from urllib.parse import urlencode

from ..core import Candle
from .base import CandleSource, Tick, aio_get, line_stream

GRAN = {60: "M1", 300: "M5"}


def _pair(symbol: str, sep: str) -> str:
    s = symbol.upper().replace("/", "").replace("_", "").replace("-", "")
    return f"{s[:3]}{sep}{s[3:6]}"


class OandaSource(CandleSource):
    group = "forex"

    def __init__(self, token: str, account: str, env: str = "practice"):
        live = env == "live"
        self._rest = "https://api-fxtrade.oanda.com" if live else "https://api-fxpractice.oanda.com"
        self._stream = "https://stream-fxtrade.oanda.com" if live else "https://stream-fxpractice.oanda.com"
        self._account = account
        self._h = {"Authorization": f"Bearer {token}", "Accept-Datetime-Format": "UNIX"}

    def __repr__(self) -> str:
        return "OandaSource(token=***)"

    async def history(self, symbol: str, tf_s: int, count: int, end_ts: int | None = None) -> list[Candle]:
        q = {"granularity": GRAN[tf_s], "price": "M", "count": min(count, 5000)}
        if end_ts:
            q["to"] = str(end_ts)
        url = f"{self._rest}/v3/instruments/{_pair(symbol, '_')}/candles?{urlencode(q)}"
        data = json.loads(await aio_get(url, self._h))
        out = []
        for c in data.get("candles", []):
            if not c.get("complete"):
                continue
            m = c["mid"]
            out.append(Candle(int(float(c["time"])), float(m["o"]), float(m["h"]), float(m["l"]), float(m["c"]), float(c.get("volume", 0))))
        return out

    async def stream(self, symbols: list[str]) -> AsyncIterator[Tick]:
        names = {_pair(s, "_"): s for s in symbols}
        url = f"{self._stream}/v3/accounts/{self._account}/pricing/stream?" + urlencode({"instruments": ",".join(names)})

        def parse(line: bytes):
            line = line.strip()
            if not line:
                return
            o = json.loads(line)
            if o.get("type") != "PRICE" or not o.get("bids") or not o.get("asks"):
                return
            mid = (float(o["bids"][0]["price"]) + float(o["asks"][0]["price"])) / 2
            yield (names.get(o["instrument"], o["instrument"]), float(o["time"]), mid)

        async for tick in line_stream(url, self._h, parse):
            yield tick


class TwelveDataSource(CandleSource):
    group = "forex"
    _IV = {60: "1min", 300: "5min"}

    def __init__(self, key: str, poll_s: float = 15.0):
        self._key = key
        self._poll = max(1.0, poll_s)

    def __repr__(self) -> str:
        return "TwelveDataSource(key=***)"

    async def history(self, symbol: str, tf_s: int, count: int, end_ts: int | None = None) -> list[Candle]:
        q = {"symbol": _pair(symbol, "/"), "interval": self._IV[tf_s], "outputsize": min(count, 5000),
             "order": "ASC", "timezone": "UTC", "apikey": self._key}
        if end_ts:
            q["end_date"] = datetime.fromtimestamp(end_ts, timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
        data = json.loads(await aio_get("https://api.twelvedata.com/time_series?" + urlencode(q)))
        if data.get("status") == "error":
            raise RuntimeError(f"Twelve Data: {data.get('message')}")
        now = time.time()
        out = []
        for v in data.get("values", []):
            ts = calendar.timegm(time.strptime(v["datetime"][:19], "%Y-%m-%d %H:%M:%S"))
            if ts + tf_s > now:
                continue  # still forming
            out.append(Candle(ts, float(v["open"]), float(v["high"]), float(v["low"]), float(v["close"]), float(v.get("volume") or 0)))
        return out

    async def stream(self, symbols: list[str]) -> AsyncIterator[Tick]:
        names = {_pair(s, "/"): s for s in symbols}
        while True:
            url = "https://api.twelvedata.com/price?" + urlencode({"symbol": ",".join(names), "apikey": self._key})
            data = json.loads(await aio_get(url))
            now = time.time()
            if len(names) == 1:
                data = {next(iter(names)): data}
            for pair, v in data.items():
                if isinstance(v, dict) and "price" in v:
                    yield (names.get(pair, pair), now, float(v["price"]))
                elif isinstance(v, dict) and v.get("status") == "error":
                    raise RuntimeError(f"Twelve Data: {v.get('message')}")
            await asyncio.sleep(self._poll)
