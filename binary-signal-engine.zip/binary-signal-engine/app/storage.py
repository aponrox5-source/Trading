"""SQLite store for closed candles and signal history (thread-safe)."""
from __future__ import annotations

import json
import sqlite3
import threading
from pathlib import Path

import pandas as pd

from .core import Candle


class Store:
    def __init__(self, path: Path):
        self._lock = threading.Lock()
        self._db = sqlite3.connect(str(path), check_same_thread=False)
        self._db.execute("PRAGMA journal_mode=WAL")
        self._db.execute("PRAGMA synchronous=NORMAL")
        self._db.execute(
            """CREATE TABLE IF NOT EXISTS candles(
                grp TEXT NOT NULL, symbol TEXT NOT NULL, tf INTEGER NOT NULL, ts INTEGER NOT NULL,
                o REAL, h REAL, l REAL, c REAL, v REAL,
                PRIMARY KEY (grp, symbol, tf, ts))"""
        )
        self._db.execute("CREATE TABLE IF NOT EXISTS signals(id TEXT PRIMARY KEY, created REAL, data TEXT)")
        self._db.commit()

    # candles -------------------------------------------------------------
    def upsert(self, grp: str, symbol: str, tf: int, candles: list[Candle]) -> None:
        if not candles:
            return
        rows = [(grp, symbol, tf, c.ts, c.o, c.h, c.l, c.c, c.v) for c in candles]
        with self._lock:
            self._db.executemany("INSERT OR REPLACE INTO candles VALUES (?,?,?,?,?,?,?,?,?)", rows)
            self._db.commit()

    def load(self, grp: str, symbol: str, tf: int, limit: int | None = None) -> pd.DataFrame:
        q = "SELECT ts,o,h,l,c,v FROM candles WHERE grp=? AND symbol=? AND tf=? ORDER BY ts DESC"
        args: list = [grp, symbol, tf]
        if limit:
            q += " LIMIT ?"
            args.append(limit)
        with self._lock:
            rows = self._db.execute(q, args).fetchall()
        df = pd.DataFrame(rows, columns=["ts", "o", "h", "l", "c", "v"])
        return df.iloc[::-1].reset_index(drop=True)

    def load_candles(self, grp: str, symbol: str, tf: int, limit: int | None = None) -> list[Candle]:
        df = self.load(grp, symbol, tf, limit)
        return [Candle(int(r.ts), r.o, r.h, r.l, r.c, r.v) for r in df.itertuples(index=False)]

    def symbols(self, grp: str, tf: int) -> list[str]:
        with self._lock:
            rows = self._db.execute("SELECT DISTINCT symbol FROM candles WHERE grp=? AND tf=?", (grp, tf)).fetchall()
        return sorted(r[0] for r in rows)

    def groups(self) -> list[str]:
        with self._lock:
            return sorted(r[0] for r in self._db.execute("SELECT DISTINCT grp FROM candles").fetchall())

    def earliest_ts(self, grp: str, symbol: str, tf: int) -> int | None:
        with self._lock:
            r = self._db.execute("SELECT MIN(ts) FROM candles WHERE grp=? AND symbol=? AND tf=?", (grp, symbol, tf)).fetchone()
        return r[0]

    # signals -------------------------------------------------------------
    def save_signal(self, sig: dict) -> None:
        with self._lock:
            self._db.execute(
                "INSERT OR REPLACE INTO signals VALUES (?,?,?)", (sig["id"], sig["created_at"], json.dumps(sig))
            )
            self._db.commit()

    def recent_signals(self, limit: int = 200) -> list[dict]:
        with self._lock:
            rows = self._db.execute("SELECT data FROM signals ORDER BY created DESC LIMIT ?", (limit,)).fetchall()
        return [json.loads(r[0]) for r in rows]
